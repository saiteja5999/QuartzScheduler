package com.juliuskrah.quartz.service;

public interface JobService {

}
